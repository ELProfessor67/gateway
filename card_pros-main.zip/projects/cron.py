

def my_scheduled_job():
    print('hello world')