from django.apps import AppConfig


class LayoutConfig(AppConfig):
    name = 'layout'
